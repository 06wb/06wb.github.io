﻿/*
*	通用方法
*	作者asd2fque1
*/
!function(wn){
	var Util={};
	Util.copyright="html词库工具，兼容各种主流操作系统，作者asd2fque1，免费提供给爱好者使用。";
	
	////常量////
	Util.CONST={};
	
	////临时变量////
	//输出文件格式（支持：UTF-8、Unicode 默认UTF-8）
	var exportFileCode="UTF-8";
	//输出文件是否包含文件头（0:不包含 1:包含 默认1）
	var exportFileContainsHead="1";
	
	////读取设置信息////
	if(localStorage.asd2fque1_config_export_file_charset){//输出文件格式
		exportFileCode=localStorage.asd2fque1_config_export_file_charset;
	}
	if(localStorage.asd2fque1_config_export_file_contains_bom){////输出文件是否包含文件头
		exportFileContainsHead=localStorage.asd2fque1_config_export_file_contains_bom;
	}
	
	////通用方法////
	Util.trimSpace=function(str){
		for(var i=0;i<str.length;i++){
			if(str.substr(i,1)!=" "){
				str=str.substr(i);
				break;
			}
		}
		for(var i=str.length-1;i>=0;i--){
			if(str.substr(i,1)!=" "){
				str=str.substr(0,i+1);
				break;
			}
		}
		return str;
	}
	Util.isEmptyObject=function(obj){
		for(var key in obj){
			return false
		};
		return true
	};

	
	////页面通用方法////
	//清空文本框
	Util.cleanTextBox=function(textDom){
		$(textDom).val("");
	};
	//读取文件内容到文本框
	Util.readFileToTextBox=function(fileDom,textDom){
		fileDom=$(fileDom);
		textDom=$(textDom);
		if(fileDom.size()==1 && (fileDom.is("input") || fileDom.is("textarea")) && fileDom.get(0).files && textDom.size()==1){
			if(fileDom.get(0).files.length<1){
//				alert("请选择一个文件。");
			}else if(fileDom.get(0).files.length>1){
				alert("不能选择多个文件。");
			}else{
				var fileObj=fileDom.get(0).files[0];
				var reader=new FileReader();
				reader.readAsText(fileObj);
				reader.onload=function(){
					textDom.val(this.result);
					fileDom.val("");
				}
			}
		}else{
			alert("error:not file dom");
		}
	};
	//选中文本框文字
	Util.selectTextBoxText=function(textDom){
		textDom=$(textDom).get(0);
		textDom.selectionStart=0;
		textDom.selectionEnd=textDom.value.length;
	}
	//下载文件
	Util.downloadFile=function(linkObj,str,fileName,charSet){
		linkObj=$(linkObj).get(0);
		var blob=null;
		var finalCharset=charSet;
		if(!finalCharset){
			finalCharset=exportFileCode;
		}
		if(finalCharset=="UTF-8"){
			blob=Util.createUtf8FileBlob(str);
		}else if(finalCharset=="Unicode"){
			blob=Util.createUnicodeFileBlob(str);
		}else if(finalCharset=="bin"){
			blob=Util.createBinFileBlob(str);
		}else{
			alert("文件编码格式设置错误");
			return;
		}
		if(fileName){
			linkObj.download=fileName;
		}else{
			linkObj.download="export.txt";
		}
		linkObj.href=URL.createObjectURL(blob);
		linkObj.click();
	}
	//生成UTF-8文件的blob
	Util.createUtf8FileBlob=function(str){//UTF-8
		var fileHead="";
		if(exportFileContainsHead=="1"){
			fileHead=new Uint8Array([0xEF,0xBB,0xBF]);//文件头
		}
		return new Blob([fileHead,str]);
	}
	//生成Unicode文件的blob
	Util.createUnicodeFileBlob=function(str){//Unicode（UTF-16le）
		var fileHead="";
		if(exportFileContainsHead=="1"){
			fileHead=new Uint8Array([0xFF,0xFE]);//文件头
		}
		var intArr=[];
		for(var i=0; i<str.length; i++){
			intArr.push(str.charCodeAt(i));
		}
		return new Blob([fileHead,new Uint16Array(intArr)]);
	}
	//生成bin文件的blob
	Util.createBinFileBlob=function(uint8Array){//Bin
		return new Blob([uint8Array]);
	}
	
	////码表通用方法////
	//读取文本行字符串，生成文本行数组
	Util.parseLineStrToLineList=function(str,isIncludeBlankLine){
		var lineList=str.split("\n");
		for(var i=lineList.length-1;i>=0;i--){
			lineList[i]=Util.trimSpace(lineList[i]);//去前后空格
			if(!isIncludeBlankLine && lineList[i]==""){
				lineList.splice(i,1);//去空行
			}
		}
		return lineList;
	}
	//根据文本行数组，生成文本行字符串
	Util.parseLineListToLineStr=function(lineList){
		var str="";
		for(var i=0;i<lineList.length;i++){
			str=str+lineList[i]+"\n";
		}
		return str;
	}
	
	////码表格式转换方法////
	//打散词条
	Util.scatter=function(str){
		var lineList=Util.parseLineStrToLineList(str);
		var newLineList=Util.scatterByList(lineList);
		return Util.parseLineListToLineStr(newLineList);
	};
	Util.scatterByList=function(lineList){
		var newLineList=[];
		var errorLineList=[];
		
		for(var i=0;i<lineList.length;i++){
			var currSplit=lineList[i].split(" ");
			if(currSplit.length>=2){
				var hasError=false;
				for(var j=1;j<currSplit.length;j++){
					if(currSplit[j].length>0){
						newLineList.push(currSplit[0]+" "+currSplit[j]);
					}else{
						hasError=true;
					}
				}
				if(hasError){
					errorLineList.push(lineList[i]);
				}
			}else{
				errorLineList.push(lineList[i]);
			}
		}
		
		if(errorLineList.length>0){
			alert("格式错误数据行：\n"+Util.parseLineListToLineStr(errorLineList));
		}
		
		return newLineList;
	};
	//合并词条
	Util.combo=function(str){
		var lineList=Util.parseLineStrToLineList(str);
		var newLineList=Util.comboByList(lineList);
		return Util.parseLineListToLineStr(newLineList);
	};
	Util.comboByList=function(lineList){
		var newLineList=[];
		var errorLineList=[];
		
		var prevCode="";
		var k=-1;
		for(var i=0;i<lineList.length;i++){
			var currSplit=lineList[i].split(" ");
			if(currSplit.length==2){
				if(currSplit[0]!=prevCode){
					newLineList.push(currSplit[0]+" "+currSplit[1]);
					k++;
					prevCode=currSplit[0];
				}else{
					newLineList[k]=newLineList[k]+" "+currSplit[1];
				}
			}else{
				errorLineList.push(lineList[i]);
			}
		}
		
		if(errorLineList.length>0){
			alert("格式错误数据行：\n"+Util.parseLineListToLineStr(errorLineList));
		}
		
		return newLineList;
	};
	//MB格式转换成打散格式词条
	Util.mbToNormal=function(str){
		var lineList=Util.parseLineStrToLineList(str);
		var newLineList=Util.mbToNormalByList(lineList);
		return Util.parseLineListToLineStr(newLineList);
	}
	Util.mbToNormalByList=function(lineList){
		var newLineList=[];
		var errorLineList=[];
		
		for(var i=0;i<lineList.length;i++){
			var currSplit=lineList[i].replace(" ","").split("\t");
			if(currSplit.length==2 && currSplit[0].length>0 && currSplit[1].length>0){
				if(lineList[i].indexOf(" ")>=0){
					errorLineList.push(lineList[i]);
				}
				newLineList.push(currSplit[1]+" "+currSplit[0]);
			}else{
				errorLineList.push(lineList[i]);
			}
		}
		
		if(errorLineList.length>0){
			alert("格式错误数据行：\n"+Util.parseLineListToLineStr(errorLineList));
		}
		
		return newLineList;
	}
	//打散格式转换成MB格式词条
	Util.normalToMb=function(str){
		var lineList=Util.parseLineStrToLineList(str);
		var newLineList=Util.normalToMbByList(lineList);
		return Util.parseLineListToLineStr(newLineList);
	}
	Util.normalToMbByList=function(lineList){
		var newLineList=[];
		var errorLineList=[];
		
		for(var i=0;i<lineList.length;i++){
			var currSplit=lineList[i].replace("\t","").split(" ");
			if(currSplit.length==2 && currSplit[0].length>0 && currSplit[1].length>0){
				if(lineList[i].indexOf("\t")>=0){
					errorLineList.push(lineList[i]);
				}
				newLineList.push(currSplit[1]+"	"+currSplit[0]);
			}else{
				errorLineList.push(lineList[i]);
			}
		}
		
		if(errorLineList.length>0){
			alert("格式错误数据行：\n"+Util.parseLineListToLineStr(errorLineList));
		}
		
		return newLineList;
	}
	//交换编码与候选的顺序
	Util.exchange=function(str){
		var lineList=Util.parseLineStrToLineList(str);
		var newLineList=Util.exchangeByList(lineList);
		return Util.parseLineListToLineStr(newLineList);
	}
	Util.exchangeByList=function(lineList){
		var newLineList=[];
		var errorLineList=[];
		
		for(var i=0;i<lineList.length;i++){
			var currSplit=lineList[i].split(" ");
			if(currSplit.length==2){
				newLineList.push(currSplit[1]+" "+currSplit[0]);
			}else{
				errorLineList.push(lineList[i]);
			}
		}
		
		if(errorLineList.length>0){
			alert("格式错误数据行：\n"+Util.parseLineListToLineStr(errorLineList));
		}
		
		return newLineList;
	}
	//去重合并词库（将str2合并到str1中）
	Util.mergeDict=function(str1,str2){
		var lineList1=Util.parseLineStrToLineList(str1);
		var lineList2=Util.parseLineStrToLineList(str2);
		var newLineList=Util.mergeDictByList(lineList1,lineList2);
		return Util.parseLineListToLineStr(newLineList);
	}
	Util.mergeDictByList=function(lineList1,lineList2){
		if(!lineList2){
			lineList2=[];
		}
		
		var newLineList=[];
		var errorLineList=[];
		
		var lineMap={};
		
		for(var i=0;i<lineList1.length;i++){
			var currSplit=lineList1[i].split(" ");
			if(currSplit.length==2){
				if(!lineMap[lineList1[i]]){
					lineMap[lineList1[i]]=lineList1[i];
				}
			}else{
				errorLineList.push(lineList1[i]);
			}
		}
		
		for(var i=0;i<lineList2.length;i++){
			var currSplit=lineList2[i].split(" ");
			if(currSplit.length==2){
				if(!lineMap[lineList2[i]]){
					lineMap[lineList2[i]]=lineList2[i];
				}
			}else{
				errorLineList.push(lineList2[i]);
			}
		}
		
		for(var line in lineMap){
			newLineList.push(line);
		}
		
		if(errorLineList.length>0){
			alert("格式错误数据行：\n"+Util.parseLineListToLineStr(errorLineList));
		}
		
		return newLineList;
	}
	
	////码表处理方法////
	//排序词条
	Util.sort=function(str){
		var lineList=Util.parseLineStrToLineList(str);
		var newLineList=Util.sortByList(lineList);
		return Util.parseLineListToLineStr(newLineList);
	};
	Util.sortByList=function(lineList){
		var newLineList=[];
		var errorLineList=[];
		
		var compareFunc=function(x,y){
			var splitX=x.split(" ");
			var splitY=y.split(" ");
			if(splitX[0]<splitY[0]){
				return -1;
			}else if(splitX[0]>splitY[0]){
				return 1;
			}else{
				return -1;//正常应该是0，返回-1解决浏览器相等顺序混乱的问题
			}
		}
		
		for(var i=lineList.length-1;i>=0;i--){
			var currSplit=lineList[i].split(" ");
			if(currSplit.length!=2){
				errorLineList.push(lineList[i]);
				lineList.splice(i,1);//去错误行
			}
		}
		
		//检测是否已经排好序
		var isSorted=true;
		for(var i=0;i<lineList.length-1;i++){
			if(compareFunc(lineList[i],lineList[i+1])>=0){
				isSorted=false;
				break;
			}
		}
		
		//是不是排序好的词库则进行排序
		if(isSorted){
			//是排序好的词库无需排序(节省处理时间)
			newLineList=lineList;
		}else{
			//不是排序好的词库则进行排序
			
			//☆解决360浏览器在排序时不能保证相同编码词条原始顺序的错误（先合并再打散）
			lineList=Util.comboByList(lineList);
			
			//调用系统排序
			newLineList=lineList.sort(compareFunc);
			
			//☆解决360浏览器在排序时不能保证相同编码词条原始顺序的错误（先合并再打散）
			newLineList=Util.scatterByList(newLineList);
		}
		
		if(errorLineList.length>0){
			alert("格式错误数据行：\n"+Util.parseLineListToLineStr(errorLineList));
		}
		
		return newLineList;
	};
	//反转词条顺序
	Util.reverse=function(str){
		var lineList=Util.parseLineStrToLineList(str);
		var newLineList=Util.reverseByList(lineList);
		return Util.parseLineListToLineStr(newLineList);
	};
	Util.reverseByList=function(lineList){
		var newLineList=[];
		var errorLineList=[];
		
		for(var i=lineList.length-1;i>=0;i--){
			var currSplit=lineList[i].split(" ");
			if(currSplit.length>=2){
				for(var j=1;j<currSplit.length;j++){
					if(currSplit[j].length<=0){
						errorLineList.push(lineList[i]);
						break;
					}
				}
				newLineList.push(lineList[i]);
			}else{
				errorLineList.push(lineList[i]);
			}
		}
		
		if(errorLineList.length>0){
			alert("格式错误数据行：\n"+Util.parseLineListToLineStr(errorLineList));
		}
		
		return newLineList;
	};
	//检测重码情况
	Util.countSameCode=function(str){
		var lineList=Util.parseLineStrToLineList(str);
		return Util.countSameCodeByList(lineList);
	};
	Util.countSameCodeByList=function(lineList){
		var resultStr="";
		var errorLineList=[];
		
		var codeNumberMap={};
		
		var sameCodeCount=0;
		var charCount=0;
		var wordCount=0;
		var i=0;
		var lastCode="";
		for(;i<lineList.length;i++){
			var currSplit=lineList[i].split(" ");
			if(currSplit.length==2){
				if(lastCode!=currSplit[0]){
					sameCodeCount++;
				}
				if(currSplit[1].length==1){
					charCount++;
				}
				if(currSplit[1].length>1){
					wordCount++;
				}
				
				if(!codeNumberMap[currSplit[0]]){
					codeNumberMap[currSplit[0]]=0;
				}
				codeNumberMap[currSplit[0]]++;
				
				lastCode=currSplit[0];
			}else{
				errorLineList.push(lineList[i]);
			}
		}
		
		var notMulCount=0;
		var maxMulNum=0;
		var codeMulCount=[];//共?个几重编码(值存个数，下标存几重)
		var codeLenCount=[];//共?个几码编码有重码(值存个数，下标存几码)
		for(var code in codeNumberMap){
			var codeMul=codeNumberMap[code];
			var codeLen=code.length;
			
			if(codeMul>1){
				if(!codeMulCount[codeMul]){
					codeMulCount[codeMul]=0;
				}
				codeMulCount[codeMul]++;
				
				if(!codeLenCount[codeLen]){
					codeLenCount[codeLen]=0;
				}
				codeLenCount[codeLen]++;
			}else{
				notMulCount++;
				maxMulNum=1;
			}
		}
		
		resultStr=resultStr+"词条共"+i+"行\n";
		resultStr=resultStr+"编码共"+sameCodeCount+"组\n";
		resultStr=resultStr+"单字共"+charCount+"个\n";
		resultStr=resultStr+"词组共"+wordCount+"个\n";
		resultStr=resultStr+"\n";
		
		resultStr=resultStr+"共"+notMulCount+"个无重码词条\n";
		for(var i=2; i<codeMulCount.length; i++){
			if(codeMulCount[i]){
				resultStr=resultStr+"共"+codeMulCount[i]+"个"+i+"重编码\n";
				maxMulNum=i;
			}
		}
		for(var i=1; i<codeLenCount.length; i++){
			if(codeLenCount[i]){
				resultStr=resultStr+"共"+codeLenCount[i]+"个"+i+"码编码有重码\n";
			}
		}
		
		resultStr=resultStr+"\n";
		if(maxMulNum>1){
			var tempCode=""
			resultStr=resultStr+"最高"+maxMulNum+"重编码\n";
			for(var code in codeNumberMap){
				if(codeNumberMap[code]==maxMulNum){
					tempCode=tempCode+"\n"+code;
				}
			}
			resultStr=resultStr+"最高重码的编码是："+tempCode+"\n";
		}else{
			resultStr=resultStr+"词库无重码\n";
		}
		
		if(errorLineList.length>0){
			alert("格式错误数据行（错误数据将不计入统计结果）：\n"+Util.parseLineListToLineStr(errorLineList));
		}
		
		return resultStr;
	};
	//出简不出全(isCharOrWord:0=单字加词组 1=仅单字 2=仅词组)
	Util.simpleNotFull=function(str,isCharOrWord){
		var lineList=Util.parseLineStrToLineList(str);
		var newLineList=Util.simpleNotFullByList(lineList,isCharOrWord);
		return Util.parseLineListToLineStr(newLineList);
	};
	Util.CONST.CHAR_OR_WORD={};
	Util.CONST.CHAR_OR_WORD.ALL=0;
	Util.CONST.CHAR_OR_WORD.CHAR=1;
	Util.CONST.CHAR_OR_WORD.WORD=2;
	Util.simpleNotFullByList=function(lineList,isCharOrWord){
		var newLineList=[];
		var errorLineList=[];
		
		if(!isCharOrWord || isCharOrWord<Util.CONST.CHAR_OR_WORD.ALL || isCharOrWord>Util.CONST.CHAR_OR_WORD.WORD){
			isCharOrWord=Util.CONST.CHAR_OR_WORD.ALL;
		}
		
		var codeCharMap={};
		
		for(var i=0;i<lineList.length;i++){
			var currSplit=lineList[i].split(" ");
			if(currSplit.length==2){
				if(isCharOrWord==Util.CONST.CHAR_OR_WORD.ALL
				|| isCharOrWord==Util.CONST.CHAR_OR_WORD.CHAR && currSplit[1].length==1
				|| isCharOrWord==Util.CONST.CHAR_OR_WORD.WORD && currSplit[1].length>1
				){
					if(!codeCharMap[currSplit[1]]){
						codeCharMap[currSplit[1]]=currSplit[0];
					}else{
						if(currSplit[0].length<codeCharMap[currSplit[1]].length){
							codeCharMap[currSplit[1]]=currSplit[0];
						}
					}
				}
			}else{
				errorLineList.push(lineList[i]);
			}
		}
		
		for(var i=0;i<lineList.length;i++){
			var currSplit=lineList[i].split(" ");
			if(currSplit.length==2){
				if(isCharOrWord==Util.CONST.CHAR_OR_WORD.ALL
				|| isCharOrWord==Util.CONST.CHAR_OR_WORD.CHAR && currSplit[1].length==1
				|| isCharOrWord==Util.CONST.CHAR_OR_WORD.WORD && currSplit[1].length>1
				){
					if(codeCharMap[currSplit[1]]==currSplit[0]){
						newLineList.push(currSplit[0]+" "+currSplit[1]);
					}
				}else{
					newLineList.push(currSplit[0]+" "+currSplit[1]);
				}
			}
		}
		
		if(errorLineList.length>0){
			alert("格式错误数据行：\n"+Util.parseLineListToLineStr(errorLineList));
		}
		
		return newLineList;
	};
	//提取词条
	Util.pickDict=function(str,codeMinLength,codeMaxLength,charMinLength,charMaxLength,isIncludeCode,isIncludeChar,isIncludeNum){
		var lineList=Util.parseLineStrToLineList(str);
		var newLineList=Util.pickDictByList(lineList,codeMinLength,codeMaxLength,charMinLength,charMaxLength,isIncludeCode,isIncludeChar,isIncludeNum);
		return Util.parseLineListToLineStr(newLineList);
	};
	Util.pickDictByList=function(lineList,codeMinLength,codeMaxLength,charMinLength,charMaxLength,isIncludeCode,isIncludeChar,isIncludeNum){
		var newLineList=[];
		var errorLineList=[];
		
		var lastCode="";
		var currCodeTimes=0;
		
		for(var i=0;i<lineList.length;i++){
			var currSplit=lineList[i].split(" ");
			if(currSplit.length==2){
				var codeLength=currSplit[0].length;
				var charLength=currSplit[1].length;
				
				if (lastCode!=currSplit[0].toLowerCase()) {
					lastCode=currSplit[0].toLowerCase();
					currCodeTimes=1;
				} else {
					currCodeTimes++;
				}
				
				if ((codeMinLength<0 || codeLength>=codeMinLength) &&
					(codeMaxLength<0 || codeLength<=codeMaxLength) &&
					(charMinLength<0 || charLength>=charMinLength) &&
					(charMaxLength<0 || charLength<=charMaxLength)
				) {
					var outCode = "";
					var outChar = "";
					var outNumber="";
					var splitSpace = "";
					
					if(isIncludeCode){
						outCode=currSplit[0];
					}
					if(isIncludeChar){
						outChar=currSplit[1];
					}
					if(isIncludeNum){
						outNumber=currCodeTimes;
					}
					if((isIncludeCode || isIncludeNum) && isIncludeChar){
						splitSpace = " ";
					}
					
					newLineList.push(outCode+outNumber+splitSpace+outChar);
				}
			}else{
				errorLineList.push(lineList[i]);
			}
		}
		
		if(errorLineList.length>0){
			alert("格式错误数据行：\n"+Util.parseLineListToLineStr(errorLineList));
		}
		
		return newLineList;
	};
	//生成百度手机输入法blob
	Util.parseBaiduBlob=function(autoCodeLength,str){
		var lineList=Util.parseLineStrToLineList(str);
		return Util.parseBaiduBlobByList(autoCodeLength,lineList);
	};
	Util.parseBaiduBlobByList=function(autoCodeLength,lineList){
		var errorLineList=[];
		var byteList=[autoCodeLength];
		var lengthList=[];
		var contentList=[];
		
		lineList=Util.sortByList(lineList);
		
		var baseLatter=0x60;//字母a的上一个字符
		var lastCode="";
		var repeatNum=1;
		for(var i=0;i<lineList.length;i++){
			var currSplit=lineList[i].split(" ");
			if(currSplit.length==2){
				var currCode=currSplit[0].toLowerCase();
				var currChar=currSplit[1];
				var codeLength=currCode.length;
				var charLength=currChar.length;
				
				if(lastCode!=currCode){
					repeatNum=1;
					lastCode=currCode;
				}else{
					repeatNum++;
				}
				if(repeatNum>99){
					//选重超过99重
					continue;
				}
				if(repeatNum<10){
					codeLength=codeLength+2;
				}else{
					codeLength=codeLength+3;
				}
				
				//计算首字母偏移量，数组作为下标
				var latterNumber=currCode.charCodeAt(0)-baseLatter;
				if(!lengthList[latterNumber]){
					lengthList[latterNumber]=0;
				}
				//累计首字母词条总长度
				lengthList[latterNumber]=lengthList[latterNumber]+2+codeLength+charLength*2+6;
				
				//写内容部分(词条)
				contentList.push(codeLength);//编码长度
				contentList.push(charLength*2+2);//候选长度
				for(var j=0;j<currCode.length;j++){
					//写编码
					contentList.push(currCode.charCodeAt(j));
				}
				
				//写重码号
				contentList.push("=".charCodeAt(0));
				if(repeatNum>=10){
					contentList.push(Math.floor(repeatNum/10)+0x30);
				}
				contentList.push(repeatNum%10+0x30);
				
				//写候选词
				for(var j=0;j<currChar.length;j++){
					var tempCharCode=currChar.charCodeAt(j);
					contentList.push(tempCharCode%0x100, Math.floor(tempCharCode/0x100)%0x100);
				}
				contentList.push(0,0,0,0,0,0);
			}else{
				errorLineList.push(lineList[i]);
			}
		}
		
		var currNum=0;
		for(var i=0;i<=26;i++){
			//写头部偏移量
			var latterLength=lengthList[i];
			if(!latterLength){
				latterLength=0;
			}
			currNum=currNum+latterLength;
			
			byteList.push(currNum%0x100, Math.floor(currNum/0x100)%0x100, Math.floor(currNum/0x10000)%0x100, Math.floor(currNum/0x1000000)%0x100);
		}
		
		byteList=byteList.concat(contentList);
		
		if(errorLineList.length>0){
			alert("格式错误数据行：\n"+Util.parseLineListToLineStr(errorLineList));
		}
		
		if(currNum>0xffffffff){
			alert("词库过大，无法生成");
			return new Blob();
		}
		
		return new Blob([new Uint8Array(byteList)]);
	};
	//生成QQ五笔输入法txt
	Util.parseQqWubi=function(str){
		var lineList=Util.parseLineStrToLineList(str);
		var newLineListObj=Util.parseQqWubiByList(lineList);
		return {normal:Util.parseLineListToLineStr(newLineListObj.normal),custom:Util.parseLineListToLineStr(newLineListObj.custom)};
	};
	Util.parseQqWubiByList=function(lineList){
		var newLineListNormal=[];
		var newLineListCustom=[];
		var errorLineList=[];
		
		lineList=Util.sortByList(lineList);
		
		var repeatCount=1;
		var lastCode="";
		for(var i=0;i<lineList.length;i++){
			var currSplit=lineList[i].split(" ");
			if(currSplit.length>=2){
				currSplit[0]=currSplit[0].toLowerCase();
				if(lastCode!=currSplit[0]){
					lastCode=currSplit[0]
					repeatCount=1;
				}
				
				var isCheckOk=false;//QQ五笔系统词库是否支持
				isCheckOk=/^[a-y]+$/.test(currSplit[0]);//编码为a到y
				if(isCheckOk){
					//候选在指定范围
					for(var j=0;j<currSplit[1].length;j++){
						var currCharCode=currSplit[1].charCodeAt(j);
						if(!(currCharCode>=0x3400&&currCharCode<=0x4db5 || currCharCode>=0x4e00&&currCharCode<=0x9faf || currCharCode>=0xe815&&currCharCode<=0x3864)){
							isCheckOk=false;
							break;
						}
					}
				}
				
				if(isCheckOk){
					newLineListNormal.push(currSplit[0]+" "+currSplit[1]);
				}else{
					newLineListCustom.push(currSplit[0]+"="+repeatCount+","+currSplit[1]);
				}
				
				repeatCount++;
			}else{
				errorLineList.push(lineList[i]);
			}
		}
		
		newLineListNormal=Util.comboByList(newLineListNormal);
		
		if(errorLineList.length>0){
			alert("格式错误数据行：\n"+Util.parseLineListToLineStr(errorLineList));
		}
		
		return {normal:newLineListNormal,custom:newLineListCustom};
	};
	//生成编码
	Util.generateCode=function(singleStr1,singleStr2,wordStr,ruleStr,isExceptWord){
		var singleLineList1=Util.parseLineStrToLineList(singleStr1);
		var singleLineList2=Util.parseLineStrToLineList(singleStr2);
		var wordLineList=Util.parseLineStrToLineList(wordStr);
		var ruleLineList=Util.parseLineStrToLineList(ruleStr,true);
		var newLineList=Util.generateCodeByList(singleLineList1,singleLineList2,wordLineList,ruleLineList,isExceptWord);
		return Util.parseLineListToLineStr(newLineList);
	};
	Util.generateCodeByList=function(singleLineList1,singleLineList2,wordLineList,ruleLineList,isExceptWord){
		var newLineList=[];
		var errorLineList=[];
		
		var tempLineList=[];
		var tempErrorLineList=[];
		
		//A组单字Map
		var singleLineMap1={};
		tempErrorLineList=[];
		for(var i=0;i<singleLineList1.length;i++){
			var currSplit=singleLineList1[i].split(" ");
			var currCode=currSplit[0];
			var currChar=currSplit[1];
			if(currSplit.length==2 && currCode.indexOf("　")<0){
				if(!singleLineMap1[currChar]){
					singleLineMap1[currChar]=[];
				}
				singleLineMap1[currChar].push(currCode);
			}else{
				tempErrorLineList.push(singleLineList1[i]);
			}
		}
		if(tempErrorLineList.length>0){
			errorLineList.push(" A组单字词条：");
			errorLineList=errorLineList.concat(tempErrorLineList);
		}
		
		//B组单字Map
		var singleLineMap2={};
		tempErrorLineList=[];
		for(var i=0;i<singleLineList2.length;i++){
			var currSplit=singleLineList2[i].split(" ");
			var currCode=currSplit[0];
			var currChar=currSplit[1];
			if(currSplit.length==2 && currCode.indexOf("　")<0){
				if(!singleLineMap2[currChar]){
					singleLineMap2[currChar]=[];
				}
				singleLineMap2[currChar].push(currCode);
			}else{
				tempErrorLineList.push(singleLineList2[i]);
			}
		}
		if(tempErrorLineList.length>0){
			errorLineList.push(" B组单字词条：");
			errorLineList=errorLineList.concat(tempErrorLineList);
		}
		
		//无编码词条List
		tempLineList=[];
		tempErrorLineList=[];
		for(var i=0;i<wordLineList.length;i++){
			if(wordLineList[i].split(" ").length==1){
				tempLineList.push(wordLineList[i]);
			}else{
				tempErrorLineList.push(wordLineList[i]);
			}
		}
		wordLineList=tempLineList;
		if(tempErrorLineList.length>0){
			errorLineList.push(" 无编码词条：");
			errorLineList=errorLineList.concat(tempErrorLineList);
		}
		
		//规则List
		tempLineList=[];
		tempErrorLineList=[];
		for(var i=0;i<ruleLineList.length;i++){
			if(/^$|^((([1-9][0-9]*[AB][R]?[1-9][0-9]*([:][R]?[1-9][0-9]*)?[UL]?)|(0[A-Z,./;'`\-=\[\]]))([ ](([1-9][0-9]*[AB][R]?[1-9][0-9]*([:][R]?[1-9][0-9]*)?[UL]?)|(0[A-Z,./;'`\-=\[\]])))*)$/i.test(ruleLineList[i])){
				var newRuleList=[];
				var oldRuleList=ruleLineList[i].split(" ");
				
				for(var j=0;j<oldRuleList.length;j++){
					var currRuleStr=oldRuleList[j];
					if(currRuleStr!=""){
						var ruleObj={
							isACharNotRule:false,//是直接字符还是规则(true：直接字符)
							charNum:0,//取第几个字的编码
							isANotB:true,//使用A组还是B组的编码(true：A组)
							numStart:0,//开始位置
							isStartFromRight:false,//开始位置是否倒数
							numEnd:0,//末尾位置
							isEndFromRight:false,//末尾位置是否倒数
							isUpperLower:0,//大小写，0不变，1大写，2小写
							str:""//字符
						};
						var tempStr="";
						
						if(currRuleStr.substr(0,1)=="0"){
							ruleObj.isACharNotRule=true;//直接字符
							ruleObj.str=currRuleStr.substr(1,1);
						}else{
							ruleObj.isACharNotRule=false;//规则
							
							currRuleStr=currRuleStr.toUpperCase();
							
							//取第几个字的编码
							tempStr=currRuleStr.match(/[0-9]+/);
							ruleObj.charNum=Number(tempStr)-1;
							currRuleStr=currRuleStr.substr(tempStr.length);
							
							//使用A组还是B组的编码
							if(currRuleStr.substr(0,1)=="A"){
								ruleObj.isANotB=true;//A
							}else{
								ruleObj.isANotB=false;//B
							}
							currRuleStr=currRuleStr.substr(1);
							
							//开始位置是否倒数
							if(currRuleStr.substr(0,1)=="R"){
								ruleObj.isStartFromRight=true;
								currRuleStr=currRuleStr.substr(1);
							}else{
								ruleObj.isStartFromRight=false;
							}
							
							//开始位置
							tempStr=currRuleStr.match(/[0-9]+/);
							ruleObj.numStart=Number(tempStr)-1;
							currRuleStr=currRuleStr.substr(tempStr.length);
							
							if(currRuleStr.length>0 && currRuleStr.substr(0,1)==":"){
								//规则中还有结束位置
								currRuleStr=currRuleStr.substr(1);
								
								//末尾位置是否倒数
								if(currRuleStr.substr(0,1)=="R"){
									ruleObj.isEndFromRight=true;
									currRuleStr=currRuleStr.substr(1);
								}else{
									ruleObj.isEndFromRight=false;
								}
								
								//末尾位置
								tempStr=currRuleStr.match(/[0-9]+/);
								ruleObj.numEnd=Number(tempStr)-1;
								currRuleStr=currRuleStr.substr(tempStr.length);
							}else{
								//规则中只有开始位置
								ruleObj.numEnd=ruleObj.numStart;
								ruleObj.isEndFromRight=ruleObj.isStartFromRight;
							}
							
							//大小写
							if(currRuleStr=="U"){
								ruleObj.isUpperLower=1;//大写
							}else if(currRuleStr=="L"){
								ruleObj.isUpperLower=2;//小写
							}
						}
						
						newRuleList.push(ruleObj);
					}
				}
				
				tempLineList.push(newRuleList);
			}else{
				tempErrorLineList.push(ruleLineList[i]);
			}
		}
		ruleLineList=tempLineList;
		if(tempErrorLineList.length>0){
			ruleLineList=[];
			tempErrorLineList.splice(0, 0, " 规则： 直接字符只支持英文字母或 , . / ; ' ` - = [ ]")
			errorLineList=tempErrorLineList.concat(errorLineList);
		}
		
		var isRuleBlank=true;
		for(var i=0;i<ruleLineList.length;i++){
			if(ruleLineList[i].length>0){
				isRuleBlank=false;
				break;
			}
		}
		if(!isRuleBlank){
			var excludeCharStrMap={};//无编码词条中包含编码A或B中没有包含的字，临时存储
			
			wordLineWarp:
			for(var i=0;i<wordLineList.length;i++){
				
				var currStr=wordLineList[i];
				var currStrLength=currStr.length;
				
				var currRuleList=ruleLineList[currStrLength-1];
				if(currRuleList && currRuleList.length>0){
					var concatedCodeList=[""];
					
					for(var j=0;j<currRuleList.length;j++){
						var currRule=currRuleList[j];
						
						if(currRule.isACharNotRule){//直接字符
							for(var k=0;k<concatedCodeList.length;k++){
								concatedCodeList[k]=concatedCodeList[k]+currRule.str;
							}
						}else{//规则
							if(currRule.charNum>=currStrLength){
								continue;
							}else{
								var currChar=currStr.substr(currRule.charNum,1);
								var currCodeList=currRule.isANotB?singleLineMap1[currChar]:singleLineMap2[currChar];
								
								if(!currCodeList){
									excludeCharStrMap[currStr]=currStr;
									continue wordLineWarp;
								}
								
								var fromNum=0;
								var endNum=0;
								var stepNum=0;
								
								var tempList=[];
								for(var k=0;k<currCodeList.length;k++){
									var currCode=currCodeList[k];
									
									//开始编码位置
									if(currRule.isStartFromRight){
										fromNum=currCode.length-1-currRule.numStart;
									}else{
										fromNum=currRule.numStart;
									}
									
									//结尾编码位置
									if(currRule.isEndFromRight){
										endNum=currCode.length-1-currRule.numEnd;
									}else{
										endNum=currRule.numEnd;
									}
									
									for(var l=0;l<concatedCodeList.length;l++){
										var concatedCode=concatedCodeList[l];
										
										var tempCodeStr="";
										for(var m=fromNum;fromNum<=endNum && m<=endNum || fromNum>endNum && m>=endNum;m+=(endNum>=fromNum?1:-1)){
											if(m>=currCode.length || m<0){
												tempCodeStr+="　";
											}else{
												tempCodeStr+=currCode.substr(m,1);
											}
										}
										
										if(currRule.isUpperLower==1){//大写
											tempCodeStr=tempCodeStr.toUpperCase();
										}else if(currRule.isUpperLower==2){//小写
											tempCodeStr=tempCodeStr.toLowerCase();
										}
										
										tempList.push(concatedCodeList[l]+tempCodeStr);
									}
								}
								concatedCodeList=tempList;
							}
						}
					}
					
					if(concatedCodeList.length==1 && concatedCodeList[0]==""){
						concatedCodeList=[];
					}
					
					for(var j=concatedCodeList.length-1;j>=0;j--){
						if(concatedCodeList[j].indexOf("　")>=0){
							if(isExceptWord==1){
								concatedCodeList.splice(j,1);
								continue;
							}else{
								concatedCodeList[j]=concatedCodeList[j].replace("　","")
								if(concatedCodeList[j].length<=0){//替换后编码不足1码时，删除当前编码
									concatedCodeList.splice(j,1);
									continue;
								}
							}
						}
						concatedCodeList[j]=concatedCodeList[j]+" "+currStr;
					}
					
//					newLineList=newLineList.concat(concatedCodeList);//数组concat在循环中效率低下，所以只能自己手写push的循环
					for(var j=0;j<concatedCodeList.length;j++){
						newLineList.push(concatedCodeList[j]);
					}
				}
			}
			
			if(!Util.isEmptyObject(excludeCharStrMap)){
				errorLineList.push(" 无编码词条中有未包含的字：");
				for(var excludeStr in excludeCharStrMap){
					errorLineList.push(excludeStr);
				}
			}
		}
		
		//去重
		newLineList=Util.mergeDictByList(newLineList);
		
		if(errorLineList.length>0){
			alert("格式错误：\n"+Util.parseLineListToLineStr(errorLineList));
		}
		
		return newLineList;
	}
	
	//功能加固组件
	!function(w,u){function i(s){return s>=0}w.Util={};for(var n in u)if(typeof u[n] == "string")if(n=="\x63\x6f\x70\x79\x72\x69\x67\x68\x74"&&i(u[n].indexOf("\u4F5C\u8005\x61\x73\x64\x32\x66\x71\x75\x65\x31")))w.Util=u;}(wn,Util);
}(window);
$(document).ready(function(){
	//设置初始焦点
	var startDom=$("#txtSource");
	if(startDom.size()>0){
		startDom.focus();
	}else{
		startDom=$("#txtSource1");
		if(startDom.size()>0){
			startDom.focus();
		}
	}
});